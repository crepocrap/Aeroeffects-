package com.pixelcut.motion

import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private sealed class ExportState {
    object Idle : ExportState()
    data class Running(val percent: Int) : ExportState()
    data class Done(val message: String) : ExportState()
    data class Failed(val message: String) : ExportState()
}

@Composable
fun EditorScreen(video: VideoItem) {
    val context = LocalContext.current

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            prepare()
        }
    }

    // Playhead position, kept in sync with the player unless the user is
    // actively dragging the timeline (isScrubbing == true).
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(video.durationMs) }
    var isScrubbing by remember { mutableStateOf(false) }

    // Trim range used for export. Defaults to the full clip.
    var trimStartMs by remember { mutableLongStateOf(0L) }
    var trimEndMs by remember(durationMs) { mutableLongStateOf(durationMs) }

    var exportState by remember { mutableStateOf<ExportState>(ExportState.Idle) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && player.duration > 0) {
                    durationMs = player.duration
                    if (trimEndMs <= 0L || trimEndMs > durationMs) {
                        trimEndMs = durationMs
                    }
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    // Poll playback position ~20x/sec while playing and not scrubbing.
    LaunchedEffect(player) {
        while (true) {
            if (!isScrubbing) {
                positionMs = player.currentPosition
            }
            kotlinx.coroutines.delay(50)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF06223f))
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp),
            factory = {
                PlayerView(context).apply {
                    useController = true
                    this.player = player
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                }
            }
        )

        Text(
            text = video.displayName,
            color = Color.White,
            modifier = Modifier.padding(start = 8.dp, top = 8.dp)
        )

        val trimmedSeconds = (trimEndMs - trimStartMs) / 1000
        Text(
            text = "القص: ${trimmedSeconds / 60}:${(trimmedSeconds % 60).toString().padStart(2, '0')} من أصل ${durationMs / 1000}ث",
            color = Color(0xFF9cc9e6),
            modifier = Modifier.padding(start = 8.dp, top = 2.dp)
        )

        TimelineView(
            durationMs = durationMs,
            positionMs = positionMs,
            onScrub = { newPos ->
                // Real-time: seek on every drag delta so the preview frame
                // updates live as the finger moves.
                isScrubbing = true
                positionMs = newPos
                player.pause()
                player.seekTo(newPos)
            },
            onScrubFinished = { isScrubbing = false },
            trimStartMs = trimStartMs,
            trimEndMs = trimEndMs,
            onTrimChange = { start, end ->
                trimStartMs = start
                trimEndMs = end
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                enabled = exportState !is ExportState.Running,
                onClick = {
                    exportState = ExportState.Running(0)
                    player.pause()
                    ExportManager.exportTrimmed(
                        context = context,
                        sourceUri = video.uri,
                        startMs = trimStartMs,
                        endMs = trimEndMs,
                        onProgress = { percent ->
                            exportState = ExportState.Running(percent)
                        },
                        onSuccess = { uri ->
                            exportState = ExportState.Done("تم الحفظ في معرض الفيديوهات ✅")
                        },
                        onError = { error ->
                            exportState = ExportState.Failed(error.message ?: "فشل التصدير")
                        }
                    )
                }
            ) {
                Text("قص وتصدير")
            }

            when (val state = exportState) {
                is ExportState.Running -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("${state.percent}%", color = Color.White)
                }
                is ExportState.Done -> Text(state.message, color = Color(0xFF7DF0FF))
                is ExportState.Failed -> Text(state.message, color = Color(0xFFFF7D7D))
                ExportState.Idle -> {}
            }
        }

        if (exportState is ExportState.Running) {
            LinearProgressIndicator(
                progress = { (exportState as ExportState.Running).percent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            )
        }
    }
}
