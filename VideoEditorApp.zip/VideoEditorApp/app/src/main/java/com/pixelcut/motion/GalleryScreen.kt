package com.pixelcut.motion

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private fun videoPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
fun GalleryScreen(onVideoSelected: (VideoItem) -> Unit) {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(false) }
    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasPermission = granted }

    LaunchedEffect(Unit) {
        val granted = androidx.core.content.ContextCompat.checkSelfPermission(
            context, videoPermission()
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) hasPermission = true
        else permissionLauncher.launch(videoPermission())
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            loading = true
            videos = VideoRepository.loadAllVideos(context)
            loading = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF06223f))
    ) {
        when {
            !hasPermission -> Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("نحتاج صلاحية الوصول للفيديوهات", color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { permissionLauncher.launch(videoPermission()) }) {
                    Text("منح الصلاحية")
                }
            }
            loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            videos.isEmpty() -> Text(
                "لا توجد فيديوهات على الجهاز",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(videos, key = { it.id }) { video ->
                    VideoThumbCell(video = video, onClick = { onVideoSelected(video) })
                }
            }
        }
    }
}

@Composable
private fun VideoThumbCell(video: VideoItem, onClick: () -> Unit) {
    val context = LocalContext.current
    var bitmap by remember(video.id) { mutableStateOf<android.graphics.Bitmap?>(null) }

    LaunchedEffect(video.id) {
        bitmap = ThumbnailCache.get(context, video)
    }

    Box(
        modifier = Modifier
            .padding(4.dp)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0a4a8f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.BottomStart
    ) {
        bitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = video.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
        }

        val seconds = video.durationMs / 1000
        Box(
            modifier = Modifier
                .padding(4.dp)
                .background(Color(0x99000000), RoundedCornerShape(6.dp))
        ) {
            Text(
                text = "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}",
                color = Color.White,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
