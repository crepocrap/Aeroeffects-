package com.pixelcut.motion

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reads every video on the device via MediaStore — no manual file picker.
 * Once the READ_MEDIA_VIDEO (or legacy READ_EXTERNAL_STORAGE) permission is
 * granted, this returns the full gallery of videos automatically.
 */
object VideoRepository {

    suspend fun loadAllVideos(context: Context): List<VideoItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<VideoItem>()

        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val name = cursor.getString(nameCol) ?: "video_$id"
                val duration = cursor.getLong(durationCol)
                val dateAdded = cursor.getLong(dateCol)
                val contentUri = ContentUris.withAppendedId(collection, id)

                result.add(
                    VideoItem(
                        id = id,
                        uri = contentUri,
                        displayName = name,
                        durationMs = duration,
                        dateAddedSec = dateAdded
                    )
                )
            }
        }

        result
    }
}
