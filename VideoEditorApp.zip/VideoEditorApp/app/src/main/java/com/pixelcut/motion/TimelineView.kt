package com.pixelcut.motion

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.max

/**
 * Timeline with:
 *  - Pinch-to-zoom (two-finger) and a slider, both changing ONLY the visual
 *    pixels-per-second scale — never the actual trimmed/edited duration.
 *  - A playhead that supports real-time drag scrubbing: as the finger moves,
 *    the line follows 1:1 and [onScrub] is called immediately on every delta
 *    so the preview player can seek live.
 *  - Two trim handles (start/end) marking the in/out points used for export.
 *    Dragging them never changes the source video, only the
 *    [trimStartMs]/[trimEndMs] range reported via [onTrimChange].
 *
 * @param durationMs total duration of the source clip in milliseconds
 * @param positionMs current playhead position in milliseconds
 * @param onScrub called continuously while dragging the playhead, with the
 *                 new position in ms (call player.seekTo(ms) here)
 * @param onScrubFinished called once when the playhead drag gesture ends
 * @param trimStartMs current trim in-point in milliseconds
 * @param trimEndMs current trim out-point in milliseconds
 * @param onTrimChange called continuously while dragging a trim handle with
 *                      the updated (start, end) pair
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun TimelineView(
    durationMs: Long,
    positionMs: Long,
    onScrub: (Long) -> Unit,
    onScrubFinished: () -> Unit = {},
    trimStartMs: Long = 0L,
    trimEndMs: Long = durationMs,
    onTrimChange: (Long, Long) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    // Visual zoom: pixels per second. Purely a display scale.
    var pxPerSec by remember { mutableFloatStateOf(60f) }
    val minPxPerSec = 10f
    val maxPxPerSec = 400f
    val minTrimGapMs = 200L

    val scrollState = rememberScrollState()

    val totalWidthPx = (durationMs / 1000f) * pxPerSec
    val playheadX = (positionMs / 1000f) * pxPerSec
    val trimStartX = (trimStartMs / 1000f) * pxPerSec
    val trimEndX = (trimEndMs / 1000f) * pxPerSec

    // Latest values, readable from inside gesture callbacks whose
    // pointerInput block is NOT re-keyed on every value change (so an
    // active drag gesture is never interrupted mid-touch).
    val latestDuration = rememberUpdatedState(durationMs)
    val latestTrimStart = rememberUpdatedState(trimStartMs)
    val latestTrimEnd = rememberUpdatedState(trimEndMs)
    val latestPosition = rememberUpdatedState(positionMs)

    Column(modifier = modifier) {
        // Zoom slider — precise zoom without pinching.
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Text("−", color = Color.White)
            Slider(
                value = pxPerSec,
                onValueChange = { pxPerSec = it },
                valueRange = minPxPerSec..maxPxPerSec,
                modifier = Modifier.weight(1f)
            )
            Text("+", color = Color.White)
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(Color(0xFF021a36))
                // Pinch-to-zoom: two-finger gesture changes pxPerSec only.
                .pointerInput(Unit) {
                    detectTransformGestures { _, _, zoom, _ ->
                        pxPerSec = (pxPerSec * zoom).coerceIn(minPxPerSec, maxPxPerSec)
                    }
                }
        ) {
            Box(
                modifier = Modifier
                    .horizontalScroll(scrollState)
                    .fillMaxHeight()
            ) {
                Box(
                    modifier = Modifier
                        .width(max(totalWidthPx, 1f).dp)
                        .fillMaxHeight()
                ) {
                    // Ruler + dimmed "will be cut" zones outside the trim range.
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val totalSeconds = (durationMs / 1000f)
                        var t = 0f
                        while (t <= totalSeconds) {
                            val x = t * pxPerSec
                            drawLine(
                                color = Color(0x55FFFFFF),
                                start = Offset(x, size.height * 0.75f),
                                end = Offset(x, size.height),
                                strokeWidth = 2f
                            )
                            t += 1f
                        }
                        if (trimStartX > 0f) {
                            drawRect(
                                color = Color(0xAA02101f),
                                topLeft = Offset(0f, 0f),
                                size = Size(trimStartX, size.height)
                            )
                        }
                        if (trimEndX < size.width) {
                            drawRect(
                                color = Color(0xAA02101f),
                                topLeft = Offset(trimEndX, 0f),
                                size = Size(size.width - trimEndX, size.height)
                            )
                        }
                    }

                    // Left trim handle.
                    TrimHandle(
                        xPx = trimStartX,
                        modifier = Modifier.pointerInput(pxPerSec) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                val newStart = (latestTrimStart.value + deltaMs)
                                    .coerceIn(0L, latestTrimEnd.value - minTrimGapMs)
                                onTrimChange(newStart, latestTrimEnd.value)
                            }
                        }
                    )

                    // Right trim handle.
                    TrimHandle(
                        xPx = trimEndX,
                        modifier = Modifier.pointerInput(pxPerSec) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                val newEnd = (latestTrimEnd.value + deltaMs)
                                    .coerceIn(latestTrimStart.value + minTrimGapMs, latestDuration.value)
                                onTrimChange(latestTrimStart.value, newEnd)
                            }
                        }
                    )

                    // Playhead — real-time drag scrubbing.
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(playheadX.toInt(), 0) }
                            .width(24.dp)
                            .fillMaxHeight()
                            .pointerInput(pxPerSec) {
                                detectDragGestures(
                                    onDragEnd = { onScrubFinished() },
                                    onDragCancel = { onScrubFinished() }
                                ) { change, dragAmount ->
                                    change.consume()
                                    val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                    val newPos = (latestPosition.value + deltaMs)
                                        .coerceIn(0L, latestDuration.value)
                                    onScrub(newPos)
                                }
                            }
                    ) {
                        Canvas(modifier = Modifier.matchParentSize()) {
                            drawLine(
                                color = Color(0xFF7DF0FF),
                                start = Offset(size.width / 2f, 0f),
                                end = Offset(size.width / 2f, size.height),
                                strokeWidth = 5f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrimHandle(xPx: Float, modifier: Modifier) {
    Box(
        modifier = modifier
            .offset { IntOffset((xPx - 10).toInt(), 0) }
            .width(20.dp)
            .fillMaxHeight()
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            drawRect(
                color = Color(0xFFFFD36E),
                topLeft = Offset(size.width / 2f - 4f, 0f),
                size = Size(8f, size.height)
            )
        }
    }
}
