package com.pixelcut.motion

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Exports the trimmed [startMs, endMs] range of [sourceUri] to a new MP4
 * and publishes it into the device's Movies/PixelCutMotion folder via
 * MediaStore, so it shows up back in the gallery like any other video.
 *
 * This performs a real re-encode via Media3 Transformer — the source file
 * is never modified, only a new, trimmed copy is written.
 */
object ExportManager {

    fun exportTrimmed(
        context: Context,
        sourceUri: Uri,
        startMs: Long,
        endMs: Long,
        outputFileName: String = "pixelcut_${System.currentTimeMillis()}.mp4",
        onProgress: (percent: Int) -> Unit,
        onSuccess: (Uri) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        require(endMs > startMs) { "endMs must be greater than startMs" }

        val clippingConfig = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(sourceUri)
            .setClippingConfiguration(clippingConfig)
            .build()

        val editedMediaItem = EditedMediaItem.Builder(mediaItem).build()

        val outFile = File(context.cacheDir, outputFileName)
        if (outFile.exists()) outFile.delete()

        val mainHandler = Handler(Looper.getMainLooper())
        val progressHolder = ProgressHolder()
        var finished = false

        lateinit var transformer: Transformer

        val pollRunnable = object : Runnable {
            override fun run() {
                if (finished) return
                val state = transformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(progressHolder.progress)
                }
                mainHandler.postDelayed(this, 250)
            }
        }

        transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    finished = true
                    onProgress(100)
                    try {
                        val publishedUri = publishToMediaStore(context, outFile, outputFileName)
                        onSuccess(publishedUri)
                    } catch (e: Exception) {
                        onError(e)
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    finished = true
                    onError(exportException)
                }
            })
            .build()

        transformer.start(editedMediaItem, outFile.absolutePath)
        mainHandler.post(pollRunnable)
    }

    private fun publishToMediaStore(context: Context, file: File, displayName: String): Uri {
        val resolver = context.contentResolver
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(
                MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/PixelCutMotion"
            )
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val itemUri = resolver.insert(collection, values)
            ?: throw IllegalStateException("MediaStore insert failed")

        resolver.openOutputStream(itemUri)?.use { out ->
            file.inputStream().use { input -> input.copyTo(out) }
        } ?: throw IllegalStateException("Could not open output stream for $itemUri")

        if (Build.VERSION.SDK_INT >= 29) {
            val update = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(itemUri, update, null, null)
        }

        return itemUri
    }
}
