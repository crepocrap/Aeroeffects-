package com.pixelcut.motion

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Pulls a real frame from each video for the gallery grid, cached in memory
 * so scrolling the grid doesn't re-decode the same video repeatedly.
 */
object ThumbnailCache {

    // Cache up to ~40 thumbnails (each ~ a few hundred KB as a downscaled bitmap).
    private val cache = object : LruCache<Long, Bitmap>(40) {
        override fun sizeOf(key: Long, value: Bitmap) = 1
    }

    suspend fun get(context: Context, video: VideoItem): Bitmap? {
        cache.get(video.id)?.let { return it }
        return withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, video.uri)
                val frame = retriever.getFrameAtTime(
                    0L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                )
                frame?.also { cache.put(video.id, it) }
            } catch (_: Exception) {
                null
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }
        }
    }
}
