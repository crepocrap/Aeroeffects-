# PixelCut Motion — Android (نسخة كاملة)

مشروع أندرويد حقيقي (Kotlin + Jetpack Compose) — بديل كامل عن نسخة الـ HTML.

## الميزات المُنفّذة فعليًا في هذه النسخة
- **معرض فيديوهات تلقائي**: بعد منح الصلاحية (`READ_MEDIA_VIDEO` على أندرويد 13+، أو `READ_EXTERNAL_STORAGE` على ما قبلها) تظهر كل فيديوهات الجهاز تلقائيًا من `MediaStore` — بدون أي اختيار يدوي أو منتقي ملفات.
- **صور مصغّرة حقيقية** لكل فيديو في شبكة المعرض (مُستخرجة عبر `MediaMetadataRetriever` ومُخزّنة مؤقتًا في الذاكرة).
- **مشغّل فيديو حقيقي** عبر `Media3 / ExoPlayer` مع أدوات تحكم (تشغيل/إيقاف).
- **Timeline Zooming**: Pinch-to-Zoom بإصبعين + شريط تمرير (Slider) — يُكبّر/يُصغّر عرض الثواني بصريًا فقط، لا يغيّر مدة الفيديو الفعلية.
- **Playhead Scrubbing**: سحب الخط العمودي يحرّك المعاينة لحظيًا (Real-time) مع كل حركة إصبع، ويوقف التشغيل تلقائيًا أثناء السحب.
- **القص الفعلي (Trim)**: مقبضان (أصفر) على طرفي التايم لاين لتحديد نقطتي البداية والنهاية.
- **التصدير الفعلي (Export)**: زر "قص وتصدير" يستخدم `Media3 Transformer` لعمل إعادة ترميز حقيقية للمقطع المحدد فقط، مع شريط تقدّم (%) مباشر، ثم يحفظ الملف الناتج في `Movies/PixelCutMotion` عبر `MediaStore` — يظهر تلقائيًا في معرض فيديوهات الجهاز. الفيديو الأصلي لا يُعدَّل أبدًا.

## كيف تبني الـ APK عبر GitHub (تلقائي بالكامل)

1. أنشئ مستودع (Repository) جديد فاضي على GitHub (أو استخدم مستودعك الحالي).
2. ارفع كل محتويات هذا المجلد:
   ```
   git init
   git add .
   git commit -m "PixelCut Motion - Android, full features"
   git branch -M main
   git remote add origin <رابط_المستودع>
   git push -u origin main
   ```
3. GitHub Actions (`.github/workflows/build.yml`) يبني APK تلقائيًا بمجرد الرفع — بدون أي أدوات على جهازك.
4. تبويب **Actions** في المستودع → آخر run → بعد الاكتمال حمّل الملف من **Artifacts** باسم `pixelcut-motion-debug-apk`.

## بنية المشروع
```
app/src/main/java/com/pixelcut/motion/
  MainActivity.kt      — التنقل بين المعرض والمحرر
  GalleryScreen.kt      — شبكة كل فيديوهات الجهاز + الصلاحية
  ThumbnailCache.kt     — استخراج/تخزين الصور المصغّرة
  VideoRepository.kt    — قراءة الفيديوهات من MediaStore
  VideoItem.kt           — نموذج البيانات
  EditorScreen.kt        — المشغّل + واجهة القص والتصدير
  TimelineView.kt         — Zoom بالقرص/الشريط + Playhead Scrubbing + مقابض القص
  ExportManager.kt        — القص الحقيقي والتصدير عبر Media3 Transformer
```

## ملاحظات
- لم تُختبر هذه النسخة على جهاز حقيقي أو محاكي بعد، لأن بيئة الكتابة هنا بلا إنترنت/SDK لتشغيل أي منهما. إن ظهر أي خطأ Build في تبويب Actions على GitHub، الصقه هنا وسيتم إصلاحه فورًا في نفس الجلسة.
- التصدير حاليًا يعيد ترميز الفيديو بالكامل (قص بدون فلاتر/تأثيرات إضافية) — هذا أسرع طريق ثابت ومضمون للحصول على ملف قابل للتشغيل في كل مكان.
